//
//  ProgressIndicator.h
//  BarCodeSampleApp
//
//  Created by Venkat on 3/31/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MBProgressHUD.h"
@interface ProgressIndicator : UIViewController

+ (MBProgressHUD *)showGlobalProgressHUDWithTitle;
+ (void)dismissGlobalHUD;
@end
