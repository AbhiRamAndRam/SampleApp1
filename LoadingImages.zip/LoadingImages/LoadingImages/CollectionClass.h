//
//  CollectionClassBackGroundCollectionViewController.h
//  BarCodeSampleApp
//
//  Created by Venkat on 12/31/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ProductDetailsData.h"
#import "UIImageView+WebCache.h"
#import "Masonry.h"

@interface CollectionClass : UIViewController<UICollectionViewDataSource,UICollectionViewDelegate>

@property (retain, nonatomic) NSString * HeadingTitle;
@property (nonatomic, retain) NSMutableArray *parsedObjArr;

@end
