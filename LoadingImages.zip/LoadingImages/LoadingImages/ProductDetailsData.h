//
//  ProductDetailsData.h
//  BarCodeSampleApp
//
//  Created by Venkat on 4/5/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ProductDetailsData : NSObject{
    NSString *CareInsYH;
    NSString *CategoryYH;
    NSString *CollectionCodeYH;
    NSString *CollectionsYH;
    NSString *ColourYH;
    NSString *CompositionYH;
    NSString *ContinuityYH;
    NSString *CutQuantity;
    NSString *DesignYH;
    NSString *ETAQuantity;
    NSString *ExtraId;
    NSString *FRTestYH;
    NSString *HSCodeYH;
    NSString *IDRPrice;
    NSString *LightYH;
    NSString *Location1YH;
    NSString *Location2YH;
    NSString *MartindaleYH;
    NSString *MasterId;
    NSString *Name;
    NSString *POQuantity;
    NSString *PillingYH;
    NSString *ProductCode;
    NSString *QtyOnHand;
    NSString *RepeatYH;
    NSString *ReservedQuantity;
    NSString *RubbingYH;
    NSString *SellingPrice;
    NSString *StatusYH;
    NSString *SupColourYH;
    NSString *SupDesignYH;
    NSString *SupplierCodeYH;
    NSString *SupplierNameYH;
    NSString *TotalAvlQuantity;
    NSString *TypeYH;
    NSString *USDPrice;
    NSString *UsageYH;
    NSString *WashingYH;
    NSString *WeightYH;
    NSString *WidthYH;
    NSString *WyzenbeekYH;
    NSString *imageYH;
    
}
@property(nonatomic,retain) NSString *CareInsYH;
@property(nonatomic,retain) NSString *CategoryYH;
@property(nonatomic,retain) NSString *CollectionCodeYH;
@property(nonatomic,retain) NSString *CollectionsYH;
@property(nonatomic,retain) NSString *ColourYH;
@property(nonatomic,retain) NSString *CompositionYH;
@property(nonatomic,retain) NSString *ContinuityYH;
@property(nonatomic,retain) NSString *CutQuantity;
@property(nonatomic,retain) NSString *DesignYH;
@property(nonatomic,retain) NSString *ETAQuantity;
@property(nonatomic,retain) NSString *ExtraId;
@property(nonatomic,retain) NSString *FRTestYH;
@property(nonatomic,retain) NSString *HSCodeYH;
@property(nonatomic,retain) NSString *IDRPrice;
@property(nonatomic,retain) NSString *LightYH;
@property(nonatomic,retain) NSString *Location1YH;
@property(nonatomic,retain) NSString *Location2YH;
@property(nonatomic,retain) NSString *MartindaleYH;
@property(nonatomic,retain) NSString *MasterId;
@property(nonatomic,retain) NSString *Name;
@property(nonatomic,retain) NSString *POQuantity;
@property(nonatomic,retain) NSString *PillingYH;
@property(nonatomic,retain) NSString *ProductCode;
@property(nonatomic,retain) NSString *QtyOnHand;
@property(nonatomic,retain) NSString *RepeatYH;
@property(nonatomic,retain) NSString *ReservedQuantity;
@property(nonatomic,retain) NSString *RubbingYH;
@property(nonatomic,retain) NSString *SellingPrice;
@property(nonatomic,retain) NSString *StatusYH;
@property(nonatomic,retain) NSString *SupColourYH;
@property(nonatomic,retain) NSString *SupDesignYH;
@property(nonatomic,retain) NSString *SupplierCodeYH;
@property(nonatomic,retain) NSString *SupplierNameYH;
@property(nonatomic,retain) NSString *TotalAvlQuantity;
@property(nonatomic,retain) NSString *TypeYH;
@property(nonatomic,retain) NSString *USDPrice;
@property(nonatomic,retain) NSString *UsageYH;
@property(nonatomic,retain) NSString *WashingYH;
@property(nonatomic,retain) NSString *WeightYH;
@property(nonatomic,retain) NSString *WidthYH;
@property(nonatomic,retain) NSString *WyzenbeekYH;
@property(nonatomic,retain) NSString *imageYH;

@end
