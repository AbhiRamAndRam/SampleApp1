//
//  BackGroundPostServiceClass.h
//  BarCodeSampleApp
//
//  Created by Venkat on 12/23/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "StaticServerVC.h"
#import "ProgressIndicator.h"

@protocol PostServiceprotocol<NSObject>
@required
- (void) PostCallService: (id)mainDictyionary;
- (void) BsicEroor1 :(NSString*)ErrorString;
@end

@interface BackGroundPostServiceClass : UIViewController

-(void)postServieCalling :(NSString*)mainurl :(NSDictionary*)params;

@property (nonatomic, strong) id<PostServiceprotocol> delegate;

@end
