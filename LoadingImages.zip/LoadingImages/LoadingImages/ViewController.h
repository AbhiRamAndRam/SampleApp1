//
//  ViewController.h
//  LoadingImages
//
//  Created by Venkat on 4/6/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BackGroundPostServiceClass.h"
#import "CollectionClass.h"

@interface ViewController : UIViewController<PostServiceprotocol>

- (IBAction)clickMe:(id)sender;

@end

