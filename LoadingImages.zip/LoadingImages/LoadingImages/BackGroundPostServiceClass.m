//
//  BackGroundPostServiceClass.m
//  BarCodeSampleApp
//
//  Created by Venkat on 12/23/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import "BackGroundPostServiceClass.h"

@interface BackGroundPostServiceClass (){
    UIView* ContentView;
}

@end

@implementation BackGroundPostServiceClass
@synthesize delegate;

- (void)viewDidLoad {
    
    [super viewDidLoad];
}

-(void)postServieCalling :(NSString*)mainurl :(NSDictionary*)params{
    
   
    NSLog(@"main url is %@",mainurl);
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:mainurl,kServerBaseURL1]]
                                    
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                    
                                                       timeoutInterval:160.0];
    
    [ProgressIndicator showGlobalProgressHUDWithTitle];
    
    [request setValue:@"application/x-www-form-urlencoded" forHTTPHeaderField:@"Content-Type"];
    [request setHTTPMethod:@"POST"];
    [request setHTTPBody:[self httpBodyForParamsDictionary:params]];
    
    //You now can initiate the request with NSURLSession or NSURLConnection, however you prefer. For example, with NSURLSession, you might do:
    
    NSURLSessionTask *task = [[NSURLSession sharedSession] dataTaskWithRequest:request completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        dispatch_async(dispatch_get_main_queue(), ^{
           [ProgressIndicator dismissGlobalHUD];
        });
        
        if (error) {
            
            NSLog(@"dataTaskWithRequest error: %@", error);
            
            NSString * BasicnetworkError = [error localizedDescription];
            NSString * AppendString = @"Http Response failed with the following ";
            NSString * networkError = [AppendString stringByAppendingString:BasicnetworkError];
            
            [self BasicError1:networkError];
        }
        
        else if ([response isKindOfClass:[NSHTTPURLResponse class]]) {
            
            NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
            
            if (statusCode != 200) {
                
               NSLog(@"Expected responseCode == 200; received %ld", (long)statusCode);
                
                NSString *statusCodeError = [NSString stringWithFormat: @"Http Response failed with the following code %ld", (long)statusCode];
                
                [self BasicError1:statusCodeError];
                
            }else{
                
                NSError *parseError;
                id responseObject = [NSJSONSerialization JSONObjectWithData:data options:0 error:&parseError];
                
                NSLog(@"else condtion");
                
                if (!responseObject) {
                    
                    NSLog(@"JSON parse error: %@", parseError);
                    
                } else {
                    
                    NSLog(@"responseObject = %@", responseObject);
                    
                    [self MainService:responseObject];
                }
                
                //if response was text/html, you might convert it to a string like so:
                // ---------------------------------
                
                NSString *responseString = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                NSLog(@"final responseString = %@", responseString);
                
               }
            }
       }];
    
    [task resume];
 }

- (NSData *)httpBodyForParamsDictionary:(NSDictionary *)paramDictionary{
    
    NSMutableArray *parameterArray = [NSMutableArray array];
    
    [paramDictionary enumerateKeysAndObjectsUsingBlock:^(NSString *key, NSString *obj, BOOL *stop) {
        NSString *param = [NSString stringWithFormat:@"%@=%@", key, [self percentEscapeString:obj]];
        [parameterArray addObject:param];
    }];
    
    NSString *string = [parameterArray componentsJoinedByString:@"&"];
    
    return [string dataUsingEncoding:NSUTF8StringEncoding];
}

- (NSString *)percentEscapeString:(NSString *)string{
    
    NSString *result = CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault,
                                                                                 (CFStringRef)string,
                                                                                 (CFStringRef)@" ",
                                                                                 (CFStringRef)@":/?@!$&'()*+,;=",
                                                                                 kCFStringEncodingUTF8));
    return [result stringByReplacingOccurrencesOfString:@" " withString:@"+"];
}

-(void)MainService :(id)mainDictionary{
    
    [delegate PostCallService :mainDictionary];
}

-(void)BasicError1:(NSString*)BasicErrotrString{
    
    [delegate BsicEroor1:BasicErrotrString];
}

@end
