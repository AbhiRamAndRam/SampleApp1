//
//  ProductDetailsData.m
//  BarCodeSampleApp
//
//  Created by Venkat on 4/5/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ProductDetailsData.h"

@implementation ProductDetailsData
@synthesize CareInsYH,CategoryYH,CollectionCodeYH,CollectionsYH,ColourYH,CompositionYH,ContinuityYH,CutQuantity,DesignYH,ETAQuantity,ExtraId,FRTestYH,HSCodeYH,IDRPrice,LightYH,Location1YH,Location2YH,MartindaleYH,MasterId,Name,POQuantity,PillingYH,ProductCode,QtyOnHand,RepeatYH,ReservedQuantity,RubbingYH,StatusYH,SupDesignYH,SupplierCodeYH,SupplierNameYH,TotalAvlQuantity,TypeYH,USDPrice,UsageYH,WashingYH,WeightYH,WidthYH,WyzenbeekYH,imageYH,SellingPrice,SupColourYH;

@end
