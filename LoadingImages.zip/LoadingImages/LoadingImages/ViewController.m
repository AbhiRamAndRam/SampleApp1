//
//  ViewController.m
//  LoadingImages
//
//  Created by Venkat on 4/6/16.
//  Copyright © 2016 Ensis. All rights reserved.
//

#import "ViewController.h"

@interface ViewController (){
    
    BackGroundPostServiceClass * post;
    NSUserDefaults * def;
}

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    def = [NSUserDefaults standardUserDefaults];
    
    post = [[BackGroundPostServiceClass alloc]init];
    post.delegate =self;
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)clickMe:(id)sender {
    
    NSDictionary *mainDictionary = [NSDictionary dictionaryWithObjectsAndKeys:
                                    @"PATTERN",@"SearchBy",
                                    @"GEOMETRICAL",@"SearchKey",
                                    @"",@"Color",
                                    @"",@"PriceFrom",
                                    @"",@"PriceTo",
                                    @"",@"QtyFrom",
                                    @"",@"QtyTo",
                                    nil];
    
    NSLog(@"main dictionary is %@",mainDictionary);
    
    [post postServieCalling:@"%@StockManager/SL/SearchProducts" :mainDictionary];
}

//Post Service protocol services starts from here:-

- (void) PostCallService:(id)mainDictyionary{
    
    dispatch_async(dispatch_get_main_queue(), ^{
        
        if ([mainDictyionary isKindOfClass:[NSDictionary class]] && mainDictyionary[@"error"]){
            
             NSLog(@"Error occured");
            
        }else if([ mainDictyionary count ] == 0){
            
            NSLog(@"No data");
            
        }else{
            
            NSArray *responseArr = [mainDictyionary mutableCopy];
            
            NSData *data = [NSKeyedArchiver archivedDataWithRootObject:responseArr];
            [def setObject:data forKey:@"parsedStockDetails"];
            
            CollectionClass *details = [self.storyboard instantiateViewControllerWithIdentifier:@"CollectionClass"];
            [self.navigationController pushViewController:details animated:YES];
        }
    });
}

-(void)BsicEroor1:(NSString *)ErrorString{
    
}

@end
