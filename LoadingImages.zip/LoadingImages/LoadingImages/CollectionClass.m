//
//  CollectionClassBackGroundCollectionViewController.m
//  BarCodeSampleApp
//
//  Created by Venkat on 12/31/15.
//  Copyright (c) 2015 Ensis. All rights reserved.
//

#import "CollectionClass.h"

@interface CollectionClass ()
{
    UICollectionView *_collectionView;
    UIImageView * Mainimage;
    UILabel * NameLabel;
    
    NSString * HeadingName;
    NSUserDefaults *def;
    NSArray *responseArr;
    NSMutableArray *pageimgsArr,*pagetitlesArr;
}
@end

@implementation CollectionClass
@synthesize HeadingTitle,parsedObjArr;

- (void)viewDidLoad {
    
    [super viewDidLoad];
    def = [NSUserDefaults standardUserDefaults];
    [self settingDataToModelClass];
    
    UICollectionViewFlowLayout *layout=[[UICollectionViewFlowLayout alloc] init];
    
    _collectionView = [[UICollectionView alloc]initWithFrame:CGRectMake(0, 0, self.view.frame.size.width, self.view.frame.size.height) collectionViewLayout:layout];
    
    [_collectionView setDataSource:self];
    [_collectionView setDelegate:self];
    
    [_collectionView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:@"cellIdentifier"];
    
    [_collectionView registerClass:[UICollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:@"HeaderView"];
    
    [_collectionView setBackgroundColor:[UIColor clearColor]];
    [_collectionView setShowsHorizontalScrollIndicator:NO];
    [_collectionView setShowsVerticalScrollIndicator:NO];
    _collectionView.contentInset = UIEdgeInsetsMake(0, 0, 130, 0);
    [self.view addSubview:_collectionView];
}

-(void)settingDataToModelClass{
    
    NSData *data = [def objectForKey:@"parsedStockDetails"];
    responseArr = [NSKeyedUnarchiver unarchiveObjectWithData:data];
    
    //  NSLog(@" Detailed screen response ---->>> %@",responseArr);
    parsedObjArr = [[NSMutableArray alloc]init];
    pageimgsArr = [[NSMutableArray array]init];
    pagetitlesArr = [[NSMutableArray array]init];
    for (NSDictionary * obj in responseArr){
        
        //   NSLog(@"ProductCode ------>>> %@",[obj objectForKey:@"ProductCode"]);
        
        ProductDetailsData *dataObj = [[ProductDetailsData alloc]init];
        
        dataObj.CareInsYH = [self handleNull:[obj objectForKey:@"CareInsYH"]];
        dataObj.CategoryYH = [self handleNull:[obj objectForKey:@"CategoryYH"]];
        dataObj.CollectionCodeYH =[self handleNull:[obj objectForKey:@"CollectionCodeYH"]];
        dataObj.CollectionsYH = [self handleNull:[obj objectForKey:@"CollectionsYH"]];
        dataObj.ColourYH = [self handleNull:[obj objectForKey:@"ColourYH"]];
        dataObj.CompositionYH = [self handleNull:[obj objectForKey:@"CompositionYH"]];
        dataObj.ContinuityYH = [self handleNull:[obj objectForKey:@"ContinuityYH"]];
        dataObj.CutQuantity = [self handleNull:[obj objectForKey:@"CutQuantity"]];
        dataObj.DesignYH = [self handleNull:[obj objectForKey:@"DesignYH"]];
        dataObj.ETAQuantity = [self handleNull:[obj objectForKey:@"ETAQuantity"]];
        
        dataObj.ExtraId = [self handleNull:[obj objectForKey:@"ExtraId"]];
        dataObj.FRTestYH = [self handleNull:[obj objectForKey:@"FRTestYH"]];
        dataObj.HSCodeYH = [self handleNull:[obj objectForKey:@"HSCodeYH"]];
        dataObj.IDRPrice = [self handleNull:[obj objectForKey:@"IDRPrice"]];
        dataObj.LightYH = [self handleNull:[obj objectForKey:@"LightYH"]];
        dataObj.Location1YH = [self handleNull:[obj objectForKey:@"Location1YH"]];
        dataObj.Location2YH = [self handleNull:[obj objectForKey:@"Location2YH"]];
        dataObj.MartindaleYH = [self handleNull:[obj objectForKey:@"MartindaleYH"]];
        dataObj.MasterId = [self handleNull:[obj objectForKey:@"MasterId"]];
        dataObj.Name = [self handleNull:[obj objectForKey:@"Name"]];
        
        dataObj.POQuantity = [self handleNull:[obj objectForKey:@"POQuantity"]];
        dataObj.PillingYH = [self handleNull:[obj objectForKey:@"PillingYH"]];
        dataObj.ProductCode = [self handleNull:[obj objectForKey:@"ProductCode"]];
        dataObj.QtyOnHand = [self handleNull:[obj objectForKey:@"QtyOnHand"]];
        dataObj.RepeatYH = [self handleNull:[obj objectForKey:@"RepeatYH"]];
        dataObj.ReservedQuantity = [self handleNull:[obj objectForKey:@"ReservedQuantity"]];
        dataObj.RubbingYH = [self handleNull:[obj objectForKey:@"RubbingYH"]];
        dataObj.SellingPrice = [self handleNull:[obj objectForKey:@"SellingPrice"]];
        dataObj.StatusYH = [self handleNull:[obj objectForKey:@"StatusYH"]];
        dataObj.SupColourYH = [self handleNull:[obj objectForKey:@"SupColourYH"]];
        
        dataObj.SupDesignYH = [self handleNull:[obj objectForKey:@"SupDesignYH"]];
        dataObj.SupplierCodeYH = [self handleNull:[obj objectForKey:@"SupplierCodeYH"]];
        dataObj.SupplierNameYH = [self handleNull:[obj objectForKey:@"SupplierNameYH"]];
        dataObj.TotalAvlQuantity = [self handleNull:[obj objectForKey:@"TotalAvlQuantity"]];
        dataObj.TypeYH = [self handleNull:[obj objectForKey:@"TypeYH"]];
        dataObj.USDPrice = [self handleNull:[obj objectForKey:@"USDPrice"]];
        dataObj.UsageYH = [self handleNull:[obj objectForKey:@"UsageYH"]];
        dataObj.WashingYH = [self handleNull:[obj objectForKey:@"WashingYH"]];
        dataObj.WeightYH = [self handleNull:[obj objectForKey:@"WeightYH"]];
        dataObj.WidthYH = [self handleNull:[obj objectForKey:@"WidthYH"]];
        
        dataObj.WyzenbeekYH = [self handleNull:[obj objectForKey:@"WyzenbeekYH"]];
        
        NSString *finalimageYh1 = [NSString stringWithFormat:@"http://203.77.214.78/StockManager%@", [obj objectForKey:@"imageYH"]];
        
        dataObj.imageYH = [self handleNull:finalimageYh1];
        
        NSLog(@"Image Url ----->>> %@",[self handleNull:finalimageYh1]); // raju
        [pageimgsArr addObject:finalimageYh1];
        [pagetitlesArr addObject:[obj objectForKey:@"ProductCode"]];
        [parsedObjArr addObject:dataObj];
    }
    NSLog(@"pageimgsArr ----->>> %@",pageimgsArr);
    NSLog(@"pagetitlesArr ----->>> %@",pagetitlesArr);
    NSLog(@"parsedObjArr Count ----->>> %lu",(unsigned long)parsedObjArr.count);
}

-(NSString*)handleNull:(NSString*)str1{
    if (str1 == nil || str1 == (id)[NSNull null]) {
        str1=@"";
    }
    return str1;
    
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
   // [_collectionView reloadData];
}

//Delegate methods of UICollectionView

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section{
    
    return parsedObjArr.count;
}
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    //  ProductDetailsData *Obj = [[ProductDetailsData alloc] init];
    ProductDetailsData *Obj = [parsedObjArr objectAtIndex:indexPath.row];
    
    UICollectionViewCell *cell=[collectionView dequeueReusableCellWithReuseIdentifier:@"cellIdentifier" forIndexPath:indexPath];
    
    for (id subview in cell.contentView.subviews) {
        if ([subview isKindOfClass:[UIImageView class]]) {
            [subview removeFromSuperview];
        } else if ([subview isKindOfClass:[UILabel class]]) {
            [subview removeFromSuperview];
        }
        else if ([subview isKindOfClass:[UITextField class]]) {
            [subview removeFromSuperview];
        }
    }
    
    Mainimage =[[UIImageView alloc]init];
    [cell.contentView addSubview:Mainimage];
    
    NameLabel = [[UILabel alloc]init];
    NameLabel.textColor = [UIColor blackColor];
    NameLabel.textAlignment = NSTextAlignmentCenter;
    NameLabel.font = [UIFont fontWithName:@"Futura" size:10.0];
    [cell.contentView addSubview:NameLabel];
    
    [Mainimage mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(@0);
        make.left.equalTo(@5);
        make.right.equalTo(@-5);
        make.height.equalTo(@55);
    }];
    
    [NameLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(Mainimage.mas_bottom).offset(3);
        make.left.equalTo(@0);
        make.right.equalTo(@0);
        make.height.equalTo(@25);
    }];
    
    NameLabel.text = Obj.ProductCode;
    
    NSLog(@"RajuImg --->>> %@",Obj.imageYH);
    
    [Mainimage sd_setImageWithURL:[NSURL URLWithString:Obj.imageYH] placeholderImage:[UIImage imageNamed:@"collectionViewIcon.png"]];
    
    cell.backgroundColor=[UIColor clearColor];
    
    return cell;
}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    
    return CGSizeMake(70, 90);
}

- (UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    
    UIEdgeInsets insets=UIEdgeInsetsMake(10, 10, 10, 10);
    return insets;
}

- (CGFloat)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout minimumLineSpacingForSectionAtIndex:(NSInteger)section {
    
    return 5.0;
}
@end
